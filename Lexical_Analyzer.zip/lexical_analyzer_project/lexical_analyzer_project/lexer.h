#ifndef LEXER_H
#define LEXER_H

void analyze_file(char *filename);

int is_operator(char ch);
int is_special_symbol(char ch);

#endif