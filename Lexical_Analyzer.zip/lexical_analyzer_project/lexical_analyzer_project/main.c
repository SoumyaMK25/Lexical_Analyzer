#include <stdio.h>
#include "lexer.h"

int main(int argc,char *argv[])
{
    if(argc!=2)
    {
        printf("Provide the input file\n");
        return 1;
    }

    analyze_file(argv[1]);

    return 0;
}