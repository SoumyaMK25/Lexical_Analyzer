#include <stdio.h>
#include <string.h>
#include "keywords.h"

char *keywords[] =
{
    "int","float","char","double","if","else","while","for","return","break","continue","void"
};

int total_keywords = 12;
int is_keyword(char *word)
{
    for(int i = 0; i < total_keywords; i++)
    {
        if(strcmp(word, keywords[i]) == 0)
        {
            return 1;
        }
    }
    return 0;
}