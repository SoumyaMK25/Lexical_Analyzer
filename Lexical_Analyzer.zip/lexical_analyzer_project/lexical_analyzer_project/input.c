#include <stdio.h>

int add(int x, int y)
{
    int result;
    result = x + y;
    return result;
}

int main()
{
    int a = 10;
    int b = 20;
    int sum;
    float average;

    char message[] = "Lexical Analyzer Test Program";

    printf("Starting Program...\n");
    printf("%s\n", message);

    sum = add(a, b);
    average = (a + b) / 2.0;

    if(sum > 20)
    {
        printf("Sum is greater than 20\n");
    }
    else if(sum == 20)
    {
        printf("Sum is exactly 20\n");
    }
    else
    {
        printf("Sum is less than 20\n");
    }

    for(int i = 0; i < 5; i++)
    {
        sum = sum + i;
        printf("Loop iteration %d\n", i);
    }

    while(a < b)
    {
        a = a + 1;
    }

    printf("Final Sum = %d\n", sum);
    printf("Average = %f\n", average);

    return 0;
}