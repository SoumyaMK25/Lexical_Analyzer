#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "lexer.h"
#include "keywords.h"

#define MAX 1000
char tokens[MAX][50];
char types[MAX][50];
int token_count = 0;
int keyword_count=0;
int identifier_count=0;
int constant_count=0;
int operator_count=0;
int symbol_count=0;

int is_duplicate(char *token)
{
    for(int i=0;i<token_count;i++)
    {
        if(strcmp(tokens[i],token)==0)
            return 1;
    }
    return 0;
}

void store_token(char *token,char *type)
{
    if(!is_duplicate(token))
    {
        strcpy(tokens[token_count],token);
        strcpy(types[token_count],type);
        token_count++;

        if(strcmp(type,"Keyword")==0) keyword_count++;
        else if(strcmp(type,"Identifier")==0) identifier_count++;
        else if(strcmp(type,"Constant")==0) constant_count++;
        else if(strstr(type,"Operator")) operator_count++;
        else if(strcmp(type,"Symbol")==0) symbol_count++;
    }
}


void analyze_file(char *filename)
{
    FILE *fp=fopen(filename,"r");

    if(fp==NULL)
    {
        printf("File not found\n");
        return;
    }

    char ch,next;
    char word[100];
    int i=0;

    while((ch=fgetc(fp))!=EOF)
    {
        //if(isalnum(ch))
         if(isalnum(ch) || ch=='_' || ch=='.' || ch=='#')
        {
            word[i++]=ch;
        }
        else
        {
            if(i!=0)
            {
                word[i]='\0';
                
                if(word[0]=='#')
                store_token(word,"Preprocessor Directive");

                else if(is_keyword(word))
                    store_token(word,"Keyword");

                else if(isdigit(word[0]))
                    store_token(word,"Constant");

                else
                    store_token(word,"Identifier");

                i=0;
            }

            if(ch == '"')
            {
            i = 0;

            while((ch = fgetc(fp)) != '"' && ch != EOF)
            {
                word[i++] = ch;
            }

            word[i] = '\0';
            store_token(word, "String Literal");
            }



            if(ch=='<'||ch=='>'||ch=='='||ch=='!')
            {
                next=fgetc(fp);

                char op[3];
                op[0]=ch;
                op[1]=next;
                op[2]='\0';

                if(next=='=')
                {
                    store_token(op,"Relational Operator");
                }
                else
                {
                    if(ch=='=')
                        store_token("=","Assignment Operator");
                    else
                    {
                        char temp[2]={ch,'\0'};
                        store_token(temp,"Relational Operator");
                    }

                    fseek(fp,-1,SEEK_CUR);
                }
            }

            else if(ch=='+'||ch=='-'||ch=='*'||ch=='/')
            {
                char temp[2]={ch,'\0'};
                store_token(temp,"Arithmetic Operator");
            }

            else if(ch=='('||ch==')'||ch=='{'||ch=='}'||ch==';'||ch==',')
            {
                char temp[2]={ch,'\0'};
                store_token(temp,"Symbol");
            }
        }
    }

    fclose(fp);

    printf("----------------------------------\n");
    printf("TOKEN           TYPE\n");
    printf("----------------------------------\n");

    for(int i=0;i<token_count;i++)
    {
        printf("%-15s %s\n",tokens[i],types[i]);
    }

    printf("\n------ Token Summary ------\n");
    printf("Keywords     : %d\n",keyword_count);
    printf("Identifiers  : %d\n",identifier_count);
    printf("Constants    : %d\n",constant_count);
    printf("Operators    : %d\n",operator_count);
    printf("Symbols      : %d\n",symbol_count);
}