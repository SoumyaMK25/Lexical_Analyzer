#ifndef KEYWORDS_H
#define KEYWORDS_H

int is_keyword(char *word);

#endif